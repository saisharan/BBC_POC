package Project_Main;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Project.lib.SeleniumFunction;

public class BBB_UI_Test_Home extends SeleniumFunction {
	
	    Properties locator_prop = new Properties();
	    Properties tdata_prop = new Properties();

	    @BeforeClass(alwaysRun = true)
	    public void setUp() throws Exception {

	        locator_prop.load(new FileInputStream("locators.properties"));
	        tdata_prop.load(new FileInputStream("testdata.properties"));
	        init(tdata_prop.getProperty("browser"));
	        System.out.println("Browser");
	    }

	    @Test
	    public void Authentication_check() throws Exception {

	        open(tdata_prop.getProperty("url"));
	        type(locator_prop.getProperty("uname"), tdata_prop.getProperty("username"));
	        type(locator_prop.getProperty("pwd"), "kingtesting");
	        keyPress(locator_prop.getProperty("pwd"), Keys.ENTER);
	        waitForPageLoaded();
	        Assert.assertTrue(isTextPresent("Inbox"));
	    }

	    @Test
	    public void ExpectedText_check() throws Exception {

	        open(tdata_prop.getProperty("url"));
	        type(locator_prop.getProperty("searchbox"), "Assignment");
	        keyPress(locator_prop.getProperty("searchbox"), Keys.ENTER);
	        waitForPageLoaded();
	        click(locator_prop.getProperty("first_search_result"));
	        waitForPageLoaded();
	        Assert.assertTrue(isTextPresent("Assignment"));
	    }

	    @Test
	    public void Signoff_Page() throws Exception {

	        open(tdata_prop.getProperty("yahoourl"));
	        click(locator_prop.getProperty("logout_page"));
	        waitForPageLoaded();
	        Assert.assertTrue(isTextPresent("Sign in to Yahoo!"));
	    }

	    @AfterClass(alwaysRun = true)
	    public void tearDown() {
	         quit();
	    }

	}


