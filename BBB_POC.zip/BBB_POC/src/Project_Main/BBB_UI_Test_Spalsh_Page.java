package Project_Main;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Project.lib.SeleniumFunction;

public class BBB_UI_Test_Spalsh_Page extends SeleniumFunction {
	Properties locator_prop = new Properties();
    Properties tdata_prop = new Properties();

    @BeforeMethod(alwaysRun = true)
    public void setUp()  {

        try {
    	locator_prop.load(new FileInputStream("locators.properties"));
        tdata_prop.load(new FileInputStream("testdata.properties"));
        }
        catch(Exception e)
        {
        	System.out.println(e.getMessage());
        }
        init(tdata_prop.getProperty("browser"));
       
    }

    @Test
    public void Search_Box_Check_Test()  {
    	
    	open(tdata_prop.getProperty("url")+"splash.html");
   	 	waitForPageLoaded();

    	 // type(locator_prop.getProperty("searchbox"), "kingtesting");
    	 //waitForPageLoaded();	
    //	 Assert.assertEquals(getElementValue(locator_prop.getProperty("searchbox")), tdata_prop.getProperty("searchbox_txt"));
    	 Assert.assertTrue(getElementValue(locator_prop.getProperty("searchbox")).contains(tdata_prop.getProperty("searchbox_txt")));
   
    }
   
    @Test
    public void FooterLink_BBBDirectory_Test() {
    	
    	 open(tdata_prop.getProperty("url")+"splash.html");
    	 waitForPageLoaded();
    	 Assert.assertTrue(isElementPresent(locator_prop.getProperty("footer_BBB_Directory")));
    	 Assert.assertEquals(getElementText(locator_prop.getProperty("footer_BBB_Directory")), tdata_prop.getProperty("footer_txt_one"));
    }
    
    @Test
    public void BackgroundImageTest() {
    	open(tdata_prop.getProperty("url")+"splash.html");
    	waitForPageLoaded();
    	Assert.assertTrue(getCssAttribute(locator_prop.getProperty("body_div"), "background").contains(tdata_prop.getProperty("background_image_url")));

    }
    
    @Test
    public void LeftNewsModuleTest() {
    	open("file:///D:/Design_Html/PhoenixDesign/index.html");
    	waitForPageLoaded();
    	Assert.assertTrue(CheckElementText(locator_prop.getProperty("left_div"), "News"));
    }
    
    @AfterMethod(alwaysRun = true)
    public void tearDown() {
         quit();
    }
}
