package Project.lib;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SeleniumFunction {
    private WebDriver driver;
    private WebElement element;

    public void init(String browser) {
        if (browser.equalsIgnoreCase("ie")) {
            System.setProperty("webdriver.ie.driver", "D:\\IEDriverServer.exe");
            DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
            driver = new InternetExplorerDriver();
        } else if (browser.equalsIgnoreCase("ff")) {
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
            driver = new ChromeDriver();
        } else {
            System.out.println("Not supported");
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @SuppressWarnings("null")
    public void keyPress(String locator, Keys keys) {
       // WebElement element = null;
        element = driver.findElement(getBySelector(locator));
        element.sendKeys(keys);
    }

    public By getBySelector(String propKey) {

        String[] split = propKey.split("++");
        String type = split[0];
        System.out.println(split[0]);
        System.out.println(split[1]);
        if (type.equalsIgnoreCase("id")) {
            return By.id(split[1]);
        } else if (type.equalsIgnoreCase("css")) {
            return By.cssSelector(split[1]);
        } else if (type.equalsIgnoreCase("tagname")) {
            return By.tagName(split[1]);
        } else if (type.equalsIgnoreCase("classname")
                || type.equalsIgnoreCase("class")) {
            return By.className(split[1]);
        } else if (type.equalsIgnoreCase("name")) {
            return By.name(split[1]);
        } else if (type.equalsIgnoreCase("xpath")) {
            return By.xpath(split[1]);
        } else if (type.equalsIgnoreCase("link")) {
            return By.linkText(split[1]);
        } else {

            try {
                throw new Exception("Invalid parmateter");
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return By.linkText(split[1]);
            }
        }

    }

    public void waitForPageLoaded() {

        try {
            //Thread.sleep(50000);
        	Thread.sleep(10000);
        } catch (Exception e) {
            //
        }
    }

    public void getTitle() {
        driver.getTitle();
    }

    public void open(String url) {
        driver.get(url);
    }

    public void type(String locator, String value) {

        element = driver.findElement(getBySelector(locator));
        element.sendKeys(value);

    }

    public void click(String locator) {
        element = driver.findElement(getBySelector(locator));
        element.click();
    }

    public String getText(String locator) {
        return driver.findElement(getBySelector(locator)).getText();
    }

    public String getElementText(String locator) {
        return driver.findElement(getBySelector(locator)).getText();
    //	return driver.findElement(By.id(locator)).getText().contains(text);
    }
    public boolean isTextPresent(String text) {
       return driver.findElement(By.tagName("Body")).getText().contains(text);
    	
    }
    
    public String getElementValue(String locator)
    {
    	return driver.findElement(getBySelector(locator)).getAttribute("value");
    }
    public void quit() {
        driver.quit();
    }
    
    public boolean isElementPresent(String locator)
    {
    	try {
    	element=driver.findElement(getBySelector(locator));
    	if (element != null)
    		return true;
    	else
    		return false;
    	} catch(Exception e)
    	{
    		System.out.println("Element not found");
    		return false;
    	}
    		
    }    
    
    public String getCssAttribute(String locator, String attribute) {
    	
    	return driver.findElement(getBySelector(locator)).getCssValue(attribute);
    	
    }
    
    public boolean CheckElementText(String locator, String text) {
    	List <WebElement> elements=driver.findElements(getBySelector(locator));
    	for (WebElement element:elements) {
    		if(element.getText().equals(text))
    			return true;
    	}
    	return false;
    }
    

}